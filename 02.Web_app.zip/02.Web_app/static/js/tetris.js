const canvas = document.getElementById('tetris');
const context = canvas.getContext('2d');
context.scale(20, 20);
canvas.width = 300; // キャンバスの幅を指定
canvas.height = 500; // キャンバスの高さを指定
context.scale(300 / 12, 500 / 20); // 描画スケールを調整


function arenaSweep() {
    outer: for (let y = arena.length - 1; y > 0; y--) {
        for (let x = 0; x < arena[y].length; x++) {
            if (arena[y][x] === 0) {
                continue outer;
            }
        }
        const row = arena.splice(y, 1)[0].fill(0);
        arena.unshift(row);
        y++;
    }
}

function collide(arena, player) {
    for (let y = 0; y < player.matrix.length; y++) {
        for (let x = 0; x < player.matrix[y].length; x++) {
            if (player.matrix[y][x] !== 0 &&
                (arena[y + player.pos.y] &&
                arena[y + player.pos.y][x + player.pos.x]) !== 0) {
                return true;
            }
        }
    }
    return false;
}

function createMatrix(w, h) {
    const matrix = [];
    while (h--) {
        matrix.push(new Array(w).fill(0));
    }
    return matrix;
}

function createPiece(type) {
    if (type === 'T') {
        return [
            [0, 0, 0],
            [1, 1, 1],
            [0, 1, 0],
        ];
    } else if (type === 'L') {
        return [
            [0, 1, 0],
            [0, 1, 0],
            [0, 1, 1],
        ];
    } else if (type === 'O') {
        return [
            [1, 1],
            [1, 1],
        ];
    } else if (type === 'Z') {
        return [
            [1, 1, 0],
            [0, 1, 1],
            [0, 0, 0],
        ];
    } else if (type === 'S') {
        return [
            [0, 1, 1],
            [1, 1, 0],
            [0, 0, 0],
        ];
    } else if (type === 'J') {
        return [
            [0, 1, 0],
            [0, 1, 0],
            [1, 1, 0],
        ];
    } else if (type === 'I') {
        return [
            [0, 1, 0, 0],
            [0, 1, 0, 0],
            [0, 1, 0, 0],
            [0, 1, 0, 0],
        ];
    }
}


function draw() {
    context.fillStyle = '#000';
    context.fillRect(0, 0, canvas.width, canvas.height);
    drawGrid();

    const excludedHeight = arena.length * 0.1 | 0;
    context.fillStyle = '#333';
    context.fillRect(0, canvas.height - excludedHeight * 20, canvas.width, excludedHeight * 20);

    drawMatrix(arena, { x: 0, y: 0 });
    drawMatrix(player.matrix, player.pos);

     // プレイ時間を表示
     context.fillStyle = 'white';
     context.font = '1px Arial';
     const timerText = getTimerText();
     context.fillText(`Time: ${timerText}`, 0.2, 2.5);

    // 速度を表示
    const speed = calculateSpeed();
    context.fillText(`Speed: ${speed}`, 0.2, 1.5);
    

}


function drawGrid() {
    context.strokeStyle = '#888'; // グリッド線の色を設定
    context.lineWidth = 0.05; // グリッド線の太さを設定
    context.setLineDash([0.1, 0.1]); // ダッシュ線のパターンを設定

    for (let x = 0; x < canvas.width; x += 1) {
        context.beginPath();
        context.moveTo(x, 0);
        context.lineTo(x, canvas.height);
        context.stroke();
    }

    for (let y = 0; y < canvas.height; y += 1) {
        context.beginPath();
        context.moveTo(0, y);
        context.lineTo(canvas.width, y);
        context.stroke();
    }
}



function drawMatrix(matrix, offset) {
    matrix.forEach((row, y) => {
        row.forEach((value, x) => {
            if (value !== 0) {
                context.fillStyle = 'blue';  
                context.fillRect(x + offset.x, y + offset.y, 1, 1);
                
                // グリッド線の描画
                context.strokeStyle = '#888'; // グリッド線の色を設定
                context.lineWidth = 0.05; // グリッド線の太さを設定
                context.setLineDash([0.1, 0.1]); // ダッシュ線のパターンを設定
                context.beginPath();
                context.rect(x + offset.x, y + offset.y, 1, 1);
                context.stroke();
            }
        });
    });
}



function merge(arena, player) {
    player.matrix.forEach((row, y) => {
        row.forEach((value, x) => {
            if (value !== 0) {
                arena[y + player.pos.y][x + player.pos.x] = value;
            }
        });
    });
}



function getTimerText() {
    const seconds = Math.floor(gameTime / 1000); // 経過時間を秒に変換
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    // ゼロパディングを行い、タイマーのテキストを作成
    return `${minutes.toString().padStart(2, '0')}:${remainingSeconds.toString().padStart(2, '0')}`;
}


function playerDrop() {
    player.pos.y++;
    if (collide(arena, player)) {
        player.pos.y--;
        merge(arena, player);
        if (player.pos.y === 0) {
            // ゲームオーバーの条件を判定
            isGameOver = true; // ゲームオーバー状態を設定
        } else {
            arenaSweep();
        }
        playerReset();
    }
    dropCounter = 0;
}


let gameTime = 0; // ゲーム内の経過時間
let isGameOver = false; // ゲームオーバーの状態を示すフラグ

function resetGame() {
    arena.forEach(row => row.fill(0)); // ゲームボードをリセット
    gameTime = 0; // ゲーム内の経過時間をリセット
    isGameOver = false; // ゲームオーバー状態をリセット
}



function playerMove(dir) {
    player.pos.x += dir;
    if (collide(arena, player)) {
        player.pos.x -= dir;
    }
}

function playerReset() {
    const pieces = 'TLOZSJI';
    player.matrix = createPiece(pieces[pieces.length * Math.random() | 0]);
    player.pos.y = 0;
    player.pos.x = (arena[0].length / 2 | 0) -
                   (player.matrix[0].length / 2 | 0);
    if (collide(arena, player)) {
        arena.forEach(row => row.fill(0));
    }
}

function rotate(matrix, dir) {
    // 行と列を転置
    for (let y = 0; y < matrix.length; ++y) {
        for (let x = 0; x < y; ++x) {
            [matrix[x][y], matrix[y][x]] = [matrix[y][x], matrix[x][y]];
        }
    }

    // ピースを回転する方向に応じて列を反転
    if (dir > 0) {
        matrix.forEach(row => row.reverse());
    } else {
        matrix.reverse();
    }
}

function playerRotate(dir) {
    const pos = player.pos.x;
    let offset = 1;
    rotate(player.matrix, dir);
    while (collide(arena, player)) {
        player.pos.x += offset;
        offset = -(offset + (offset > 0 ? 1 : -1));
        if (offset > player.matrix[0].length) {
            rotate(player.matrix, -dir);
            player.pos.x = pos;
            return;
        }
    }
}

function adjustDropInterval() {
    // 例: 1分(60000ミリ秒)ごとに落下速度を50ミリ秒減少させる
    const speedIncreaseInterval = 30000; // 1分
    const speedIncreaseAmount = 25; // 25ミリ秒

    // 経過時間に応じて落下速度を調整
    const intervalsPassed = Math.floor(gameTime / speedIncreaseInterval);
    dropInterval = 500 - (intervalsPassed * speedIncreaseAmount);

    // 落下速度の最小値を設定 (例: 100ミリ秒)
    if (dropInterval < 100) {
        dropInterval = 100;
    }
}

function calculateSpeed() {
    const speedIncreaseInterval = 30000; // 1分
    const intervalsPassed = Math.floor(gameTime / speedIncreaseInterval);
    return intervalsPassed; // 速度は経過した分の数と同じ
}

let dropCounter = 0;
let dropInterval = 500;

let lastTime = 0;

function update(time = 0) {
    const deltaTime = time - lastTime;
    lastTime = time;
    dropCounter += deltaTime;
    if (dropCounter > dropInterval) {
        playerDrop();
    }
    draw();
    requestAnimationFrame(update);
}

const arena = createMatrix(12, 20);

const player = {
    pos: { x: 5, y: 5 },
    matrix: createPiece('T'),
};

//document.addEventListener('keydown', event => {
//    if (event.keyCode === 37) {
//        playerMove(-1);
//    } else if (event.keyCode === 39) {
 //       playerMove(1);
   // } else if (event.keyCode === 40) {
   //     playerDrop();
   // } else if (event.keyCode === 81) { 
   //     playerRotate(-1);
    //} else if (event.keyCode === 69) {
    //    playerRotate(1);
   // }
//});

const socket = io.connect('http://' + document.domain + ':' + location.port);

socket.on('move_left', function() {
    playerMove(1);  // テトリスのブロックを左に移動
});

socket.on('move_right', function() {
    playerMove(-1);  // テトリスのブロックを右に移動
});

socket.on('rotate_right', function() {
    playerRotate(1);  // テトリスのブロックを回転
});

socket.on('rotate_left', function() {
    playerRotate(-1);  // テトリスのブロックを回転
});

function update(time = 0) {
    if (!isGameOver) {
        const deltaTime = time - lastTime;
        lastTime = time;
        gameTime += deltaTime; // 経過時間を更新

        adjustDropInterval();  // 落下速度を調整

        dropCounter += deltaTime;
        if (dropCounter > dropInterval) {
            playerDrop();
        }
        draw();
        requestAnimationFrame(update);
    } else {
        // ゲームオーバー時の処理
        resetGame(); // ゲームをリセット
    }
}



update();

