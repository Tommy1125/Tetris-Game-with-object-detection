
import mediapipe as mp
import cv2
from flask_socketio import SocketIO
import time
import numpy as np

def OD(socketio):
    def calculate_distance(point1, point2):
        return np.sqrt((point2[0] - point1[0])**2 + (point2[1] - point1[1])**2)

    mp_drawing = mp.solutions.drawing_utils
    mp_holistic = mp.solutions.holistic
    mp_drawing.DrawingSpec(color=(0,0,255), thickness=2, circle_radius=2)
    mp_drawing.draw_landmarks

    cap = cv2.VideoCapture(0)

    last_emit_time = time.time()

    replacement_face = cv2.imread('static/image.PNG') 
    replacement_face = cv2.cvtColor(replacement_face, cv2.COLOR_BGR2RGB)
    # Initiate holistic model
    with mp_holistic.Holistic(min_detection_confidence=0.5, min_tracking_confidence=0.5) as holistic:
        
        while cap.isOpened():
            ret, frame = cap.read()
            if not ret:
                continue
            # Recolor Feed
            frame = cv2.flip(frame, 1)
            image = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            # Make Detections
            results = holistic.process(image)
            # print(results.face_landmarks)
            
            if results.left_hand_landmarks:
                left_thumb = results.left_hand_landmarks.landmark[mp_holistic.HandLandmark.THUMB_TIP]
                left_index_finger = results.left_hand_landmarks.landmark[mp_holistic.HandLandmark.INDEX_FINGER_TIP]
                h, w, _ = image.shape
                left_thumb_x, left_thumb_y = int(left_thumb.x * w), int(left_thumb.y * h)
                left_index_finger_x, left_index_finger_y = int(left_index_finger.x * w), int(left_index_finger.y * h)
                left_distance = calculate_distance((left_thumb_x, left_thumb_y), (left_index_finger_x, left_index_finger_y))
                cv2.circle(image, (left_thumb_x, left_thumb_y), 15, (0, 255, 0), 3)  # 緑の円を描画
                cv2.circle(image, (left_index_finger_x, left_index_finger_y), 15, (0, 255, 0), 3)  # 緑の円を描画
                if left_distance < 50:
                    current_time = time.time()  # 現在の時間を取得
                    # 前回のメッセージ送信から0.5秒以上経過していれば新しいメッセージを送信
                    if current_time - last_emit_time >= 0.5:
                        socketio.emit('rotate_left')
                        last_emit_time = current_time  # 最後のメッセージ送信時刻を更新
                else:    
                    current_time = time.time()  # 現在の時間を取得
                    # 前回のメッセージ送信から0.5秒以上経過していれば新しいメッセージを送信
                    if current_time - last_emit_time >= 0.5:
                        socketio.emit('move_left')
                        last_emit_time = current_time  # 最後のメッセージ送信時刻を更新

            # 右手のランドマークが検出された場合
            if results.right_hand_landmarks:
                right_thumb = results.right_hand_landmarks.landmark[mp_holistic.HandLandmark.THUMB_TIP]
                right_index_finger = results.right_hand_landmarks.landmark[mp_holistic.HandLandmark.INDEX_FINGER_TIP]
                h, w, _ = image.shape
                right_thumb_x, right_thumb_y = int(right_thumb.x * w), int(right_thumb.y * h)
                right_index_finger_x, right_index_finger_y = int(right_index_finger.x * w), int(right_index_finger.y * h)
                right_distance = calculate_distance((right_thumb_x, right_thumb_y), (right_index_finger_x, right_index_finger_y))
                cv2.circle(image, (right_thumb_x, right_thumb_y), 15, (0, 255, 0), 3)  # 緑の円を描画
                cv2.circle(image, (right_index_finger_x, right_index_finger_y), 15, (0, 255, 0), 3)  # 緑の円を描画

                if right_distance < 50:
                    current_time = time.time()  # 現在の時間を取得
                    # 前回のメッセージ送信から0.5秒以上経過していれば新しいメッセージを送信
                    if current_time - last_emit_time >= 0.5:
                        socketio.emit('rotate_right')
                        last_emit_time = current_time  # 最後のメッセージ送信時刻を更新
                else:
                    current_time = time.time()
                    if current_time - last_emit_time >= 0.5:
                        socketio.emit('move_right')
                        last_emit_time = current_time

            if results.face_landmarks:
                face_landmarks = results.face_landmarks.landmark
                h, w, _ = image.shape
                x1 = int(face_landmarks[54].x * w)
                y1 = int(face_landmarks[54].y * h)
                x2 = int(face_landmarks[288].x * w)
                y2 = int(face_landmarks[288].y * h)
                cv2.rectangle(image, (x1, y1), (x2, y2), (0, 255, 0), 2)
                # Ensure top_left and bottom_right are correctly assigned
                top_left = [min(x1, x2), min(y1, y2)]
                bottom_right = [max(x1, x2), max(y1, y2)]
                
                width_diff = bottom_right[0] - top_left[0]
                height_diff = bottom_right[1] - top_left[1]
                
                # Proceed if width and height differences are positive
                if width_diff > 0 and height_diff > 0:
                    actual_shape = image[top_left[1]:bottom_right[1], top_left[0]:bottom_right[0]].shape
                    if actual_shape[1] > 0 and actual_shape[0] > 0:
                        resized_face = cv2.resize(replacement_face, (actual_shape[1], actual_shape[0]))
                        image[top_left[1]:bottom_right[1], top_left[0]:bottom_right[0]] = resized_face
                    else:
                    # 幅または高さが0または負の値の場合、エラーメッセージを表示する（オプション）
                        print("No detecting complete face")


            # face_landmarks, pose_landmarks, left_hand_landmarks, right_hand_landmarks
            
            # Recolor image back to BGR for rendering
            image = cv2.cvtColor(image, cv2.COLOR_RGB2BGR)
            
            # 1. Draw face landmarks
            mp_drawing.draw_landmarks(image, results.face_landmarks, mp_holistic.FACEMESH_TESSELATION, 
                                    mp_drawing.DrawingSpec(color=(80,110,10), thickness=1, circle_radius=1),
                                    mp_drawing.DrawingSpec(color=(80,256,121), thickness=1, circle_radius=1)
                                    )
            
            # 2. Right hand
            mp_drawing.draw_landmarks(image, results.right_hand_landmarks, mp_holistic.HAND_CONNECTIONS, 
                                    mp_drawing.DrawingSpec(color=(80,22,10), thickness=2, circle_radius=4),
                                    mp_drawing.DrawingSpec(color=(80,44,121), thickness=2, circle_radius=2)
                                    )

            # 3. Left Hand
            mp_drawing.draw_landmarks(image, results.left_hand_landmarks, mp_holistic.HAND_CONNECTIONS, 
                                    mp_drawing.DrawingSpec(color=(121,22,76), thickness=2, circle_radius=4),
                                    mp_drawing.DrawingSpec(color=(121,44,250), thickness=2, circle_radius=2)
                                    )

            # 4. Pose Detections
            mp_drawing.draw_landmarks(image, results.pose_landmarks, mp_holistic.POSE_CONNECTIONS, 
                                    mp_drawing.DrawingSpec(color=(245,117,66), thickness=2, circle_radius=4),
                                    mp_drawing.DrawingSpec(color=(245,66,230), thickness=2, circle_radius=2)
                                    )
            ret, buffer = cv2.imencode('.jpg', image)
            frame = buffer.tobytes()
            yield (b'--frame\r\n'
                   b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')

